//
//  MyCollectionViewCell2.swift
//  iConiki
//
//  Created by Raphael Alkamim on 24/06/21.
//

import UIKit

class MyCollectionViewCell2: UICollectionViewCell {
   
    @IBOutlet weak var imgCard: UIImageView!
    @IBOutlet weak var titleCard: UILabel!
    @IBOutlet weak var textCard: UILabel!
    
}

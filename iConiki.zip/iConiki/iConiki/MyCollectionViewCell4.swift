//
//  MyCollectionViewCell4.swift
//  iConiki
//
//  Created by Raphael Alkamim on 29/06/21.
//

import UIKit

class MyCollectionViewCell4: UICollectionViewCell {
    @IBOutlet weak var iconTitle: UILabel!
    @IBOutlet weak var iconImg: UIImageView!
    
}

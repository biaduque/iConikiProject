//
//  MyCollectionViewCell3.swift
//  iConiki
//
//  Created by Raphael Alkamim on 29/06/21.
//

import UIKit

class MyCollectionViewCell3: UICollectionViewCell {
    
    
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var iconTitle: UILabel!
    
}


class MyCollectionViewCell4: UICollectionViewCell {
    @IBOutlet weak var iconTitle: UILabel!
    @IBOutlet weak var iconImg: UIImageView!
    
}


class MyCollectionViewCell5: UICollectionViewCell {
    
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var iconTitle: UILabel!
    
}

class MyCollectionViewCell6: UICollectionViewCell {
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var iconTitle: UILabel!
    
}

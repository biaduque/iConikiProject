//
//  DiscoverViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 24/06/21.
//

import UIKit

class DiscoverViewController: UIViewController {

    @IBOutlet weak var tittle: UILabel?
    var card = 0
    let titulos: [String] = ["Qual o conceito de unidade?", "Qual o conceito de Alinhamento?","Qual o conceito de Brevidade?"]
    let texto: [String] = ["Quando ícones são desenvolvidos em conjunto, é necessário que hajam padrões estéticos que uniformizem os ícones desenvolvidos, como estilo, ângulos, cores, peso das linhas, etc. Os ícones devem manter padrões quando trabalhados em conjunto, para que se tornem reconhecíveis dentro de um determinado sistema de comunicação. Isso quer dizer que quando são colocados um ao lado do outro, devem parecer da mesma família e demonstrar uma identidade única. Isso envolve se são preenchidos ou não, o peso dos traços, cores e sombras, a perspectiva, os tamanhos e as formas.", "Para atribuir equilíbrio aos ícones, é preciso trabalhar com alinhamento. Essas medidas exatas resultam em um design mais consistente e permitem que os ícones não fiquem desbalanceados. Para garantir um bom alinhamento, é importante usar as ferramentas que trarão medidas exatas, mas também é importante fazer um bom uso dos seus próprios olhos, levando em consideração que nem sempre o alinhamento perfeito é agradável à percepção visual humana.","Ícones não podem possuir detalhes demais em seus desenhos. Isso porque, com muitos detalhes eles podem ficar poluídos e confusos, atrasando o entendimento. Também é importante lembrar que, na maioria das vezes, ícones são apresentados em tamanhos pequenos, e por isso, se houver muitos detalhes a imagem pode ficar borrada e confusa. O ideal é manter a simplicidade."]
    let imgExemplo: [String] = ["DiscoverUnidade","DiscoverBrevidade","DiscoverAlinhamento"]
    let exemplo1: [String]  = ["UnidadeExemplo1","BrevidadeExemplo1","AlinhamentoExemplo1"]
    let exemplo2: [String]  = ["UnidadeExemplo2","BrevidadeExemplo2","AlinhamentoExemplo2"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (card != 3){
            tittle?.text = titulos[card]
        } else {
            tittle?.text = "Error"
            
            
        }
        
        
        

      
    }


}

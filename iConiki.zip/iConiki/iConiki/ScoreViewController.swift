//
//  ScoreViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 25/06/21.
//

import UIKit

class ScoreViewController: UIViewController {

    @IBOutlet weak var scoreResult: UILabel?
    @IBOutlet weak var feedbackEnd: UIImageView?
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var textMotivation: UILabel?
    
    let reacoes =  ["Feliz","Médio","Triste"]
    
    var score: Int = 0
    
    let text = ["Incrível!", "Bom!", "Ops!"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menuButton?.backgroundColor = colorBlue
        menuButton?.layer.cornerRadius = 15
        
        scoreResult?.text = "\(score)/5"
        artFinal()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    func artFinal(){
        if score == 5 {
            feedbackEnd?.image = UIImage (named: reacoes[0])
            textMotivation?.text = text[0]
            
        } else if score >= 3 {
            feedbackEnd?.image = UIImage (named: reacoes[1])
            textMotivation?.text = text[1]
            
        } else {
            feedbackEnd?.image = UIImage (named: reacoes[2])
            textMotivation?.text = text[2]
        }
    
    }
    
    @IBAction func returnMenu(_ sender: UIButton) {
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers as [UIViewController]
        self.navigationController!.popToViewController(viewControllers [viewControllers.count-4], animated: true)
    }
    

}

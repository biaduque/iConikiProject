//
//  ScoreViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 25/06/21.
//

import UIKit

class ScoreViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


}

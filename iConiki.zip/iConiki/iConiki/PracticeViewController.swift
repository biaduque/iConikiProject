//
//  PracticeViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 24/06/21.
//

import UIKit



class PracticeViewController: UIViewController{
   
    @IBOutlet weak var exemplo2: UIImageView?
    
    @IBOutlet weak var buttonRight: UIButton!
    @IBOutlet weak var buttonWrong: UIButton!
    @IBOutlet weak var exemplo1: UIImageView?
    @IBOutlet weak var texto: UILabel?
    @IBOutlet weak var button: UIButton?
    
    let textos: [String] = ["Você consegue indicar quais ícones estão seguindo o conceito de Unidade?", "Você consegue indicar quais ícones estão seguindo o conceito de Brevidade?", "Você consegue indicar quais ícones estão seguindo o conceito de Alinhamento?" ]
    
    let exemplos1: [String]  = ["UnidadeExemplo1","BrevidadeExemplo1","AlinhamentoExemplo1"]
    let exemplos2: [String]  = ["UnidadeExemplo2","BrevidadeExemplo2","AlinhamentoExemplo2"]
    
    

    @IBOutlet weak var text1: UILabel!
    var card = 0
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonWrong?.tintColor = colorOrange
        buttonRight?.tintColor = colorBlue
        
        button?.backgroundColor = colorBlue
        button?.layer.cornerRadius = 15
        
        if (card != 3){
            texto?.text = textos[card]
            exemplo1?.image = UIImage(named: exemplos1[card])
            exemplo2?.image = UIImage(named: exemplos2[card])
    

        }


   
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "transitionGameViewController" {
                let gameViewController = segue.destination as? GameViewController
                    gameViewController?.card = card
                
            }
        }

 

}

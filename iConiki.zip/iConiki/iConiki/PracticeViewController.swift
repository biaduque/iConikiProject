//
//  PracticeViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 24/06/21.
//

import UIKit

class PracticeViewController: UIViewController{

    @IBOutlet weak var text1: UILabel!
    var card = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        text1.text = "\(card)"
        

   
    }
    


 

}

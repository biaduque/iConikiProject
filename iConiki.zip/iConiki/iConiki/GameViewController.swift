//
//  GameViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 25/06/21.
//

import UIKit


class GameViewController: UIViewController {
    
    
    
    @IBOutlet weak var label1: UILabel?
    @IBOutlet weak var imgQuestion: UIImageView?
    @IBOutlet weak var buttonNegative: UIButton?
    @IBOutlet weak var buttonPositive: UIButton?
    @IBOutlet weak var progressView: UIProgressView?
    @IBOutlet weak var buttonNext: UIButton?
    
    
    var card = 0
    var resposta = "x"
    var acertou: Bool =  false
    var questions = 0
    var usados: [Int] = []
    var permitidoMudar: Bool = false
    var permitidoResponder: Bool = true
    
    let progress = Progress(totalUnitCount: 5)
    
    var unidadeQuestions = ["Unidade1","Unidade2","Unidade3","Unidade4","Unidade5","Unidade6","Unidade7","Unidade8","Unidade9","Unidade10"]
    var unidadeAnswers = ["f", "v", "f", "v", "f", "v", "f", "f","v", "f"]
    
    var brevidadeQuestions = ["Brevidade1","Brevidade2","Brevidade3","Brevidade4","Brevidade5","Brevidade6","Brevidade7","Brevidade8","Brevidade9","Brevidade10"]
    var brevidadeAnswers = ["v","v","v","f","f","f","f","v","v","v"]
    
    var alinhametoQuestions = ["Alinhamento1","Alinhamento2","Alinhamento3","Alinhamento4","Alinhamento5","Alinhamento6","Alinhamento7","Alinhamento8","Alinhamento9","Alinhamento10"]
    var alinhamentoAnswers = ["f","v","v","f","f","f","f","v","v","f"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonNegative?.tintColor = colorOrange
        buttonPositive?.tintColor = colorBlue
        buttonNext?.tintColor = .systemGray
        
        label1?.text = "\(card)"
        
        progressView?.transform = progressView!.transform.scaledBy(x: 1, y: 5)
        
        if (card == 0) {
            choosePhase(questoes: unidadeQuestions, respostas: unidadeAnswers)
        } else if (card == 1) {
            choosePhase(questoes: brevidadeQuestions, respostas:brevidadeAnswers)
        } else {
            choosePhase(questoes: alinhametoQuestions, respostas: alinhamentoAnswers)
        }
        
        
        
    }
    
    
    func choosePhase(questoes: [String], respostas: [String]) {
        
        if (questions < 4){
            var indice = Int.random(in: 0..<questoes.count)
            while (usados.contains(indice)){
                indice = Int.random(in: 0..<questoes.count)
            }
            usados.append(indice)
            imgQuestion?.image = UIImage (named: questoes[indice])
        
            if respostas[indice] == "v"{
                buttonPositive?.tag = 1
                buttonNegative?.tag = 0
            } else {
                buttonPositive?.tag = 0
                buttonNegative?.tag = 1
            }
        }
        
    }
    
    @IBAction func feedback(_ sender: UIButton) {
        
        if permitidoResponder == true {
            permitidoResponder = false
            permitidoMudar = true
            buttonNext?.tintColor = .systemBlue
            
            self.progress.completedUnitCount += 1
            let progressFloat = Float(self.progress.fractionCompleted)
            self.progressView?.setProgress(progressFloat, animated: true)
            
            if sender.tag == 1 {
                label1?.text = "acertou"
            } else{
                label1?.text = "erroooou"
            }
        }
       
    }
    
    
    @IBAction func nextQuestion(_ sender: UIButton) {
        
        if permitidoMudar == true {
            permitidoMudar = false
            permitidoResponder = true
            buttonNext?.tintColor = .systemGray
            
            
            if questions < 4 {
                if (card == 0) {
                    choosePhase(questoes: unidadeQuestions, respostas: unidadeAnswers)
                } else if (card == 1) {
                    choosePhase(questoes: brevidadeQuestions, respostas:brevidadeAnswers)
                } else {
                    choosePhase(questoes: alinhametoQuestions, respostas: alinhamentoAnswers)
                }
            } else {
                let scoreViewController = self.storyboard?.instantiateViewController(withIdentifier: "scoreViewController") as! ScoreViewController

                self.navigationController?.pushViewController(scoreViewController, animated: true)
            }
            
            questions += 1
            
           
        }
            
    }
        
       
    
}

//
//  IconsViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 29/06/21.
//

import UIKit

class IconsViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    
    
    
    @IBOutlet weak var viewCell: UICollectionView!
    @IBOutlet weak var viewCell2: UICollectionView!
    @IBOutlet weak var viewCell3: UICollectionView!
    @IBOutlet weak var viewCell4: UICollectionView!
    
    
    var items = ["sunrise.fill","cloud.rain","thermometer","tornado","sun.max.fill","cloud.moon.rain","moon.stars.fill","wind", "sun.haze","thermometer.snowflake"]
    var items2 = ["keyboard","printer.fill","scanner","tv","macpro.gen1","laptopcomputer","ipod","iphone", "applewatch.watchface","airpodspro"]
    var items3 = ["flame.fill","bolt","hare","tortoise.fill","leaf","ant.circle.fill","ladybug","bolt.slash.circle", "drop.fill","leaf.arrow.triangle.circlepath"]
    var items4 = ["cart","creditcard.fill","giftcard","dollarsign.circle.fill","banknote","signature","bag.fill","percent", "bicycle","figure.walk"]
    
    
    let reuseIdentifier3 = "cell3"
    let reuseIdentifier4 = "cell4"
    let reuseIdentifier5 = "cell5"
    let reuseIdentifier6 = "cell6"
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == viewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier3, for: indexPath as IndexPath) as! MyCollectionViewCell3
            
            
            cell.iconTitle.text = self.items[indexPath.row]
            //cell.iconImg.backgroundColor =  .blue
            cell.iconImg.image = UIImage(systemName: items[indexPath.row])
            
            
            cell.layer.cornerRadius = 15
            
            
            return cell
        } else if collectionView == viewCell2 {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier4, for: indexPath as IndexPath) as! MyCollectionViewCell4
            
            
            cell.iconTitle.text = self.items2[indexPath.row]
            //cell.iconImg.backgroundColor =  .brown
            cell.iconImg.image = UIImage(systemName: items2[indexPath.row])
            
            
            cell.layer.cornerRadius = 15
            
            
            return cell
            
        } else if collectionView == viewCell3 {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier5, for: indexPath as IndexPath) as! MyCollectionViewCell5
            
            
            cell.iconTitle.text = self.items3[indexPath.row]
            //cell.iconImg.backgroundColor =  .cyan
            cell.iconImg.image = UIImage(systemName: items3[indexPath.row])
            
            
            cell.layer.cornerRadius = 15
            
            
            return cell
            
        } else {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier6, for: indexPath as IndexPath) as! MyCollectionViewCell6
            
            
            cell.iconTitle.text = self.items4[indexPath.row]
            //cell.iconImg.backgroundColor =  .yellow
            cell.iconImg.image = UIImage(systemName: items4[indexPath.row])
            
            
            cell.layer.cornerRadius = 15
            
            
            return cell
            
        }
    }
    
}

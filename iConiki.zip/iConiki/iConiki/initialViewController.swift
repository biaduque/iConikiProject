//
//  initialViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 30/06/21.
//

import UIKit

class initialViewController: UIViewController {
    
    @IBOutlet weak var button: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        button?.backgroundColor = .systemOrange
        button?.layer.cornerRadius = 15
        
    }
    

}

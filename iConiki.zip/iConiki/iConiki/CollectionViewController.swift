//
//  ViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 23/06/21.
//

import UIKit

class CollectionViewController: UIViewController {
    
    @IBOutlet weak var card1: UIView!
    @IBOutlet weak var button1: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
    }


    
}


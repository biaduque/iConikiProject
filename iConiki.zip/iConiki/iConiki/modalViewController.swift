//
//  modalViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 30/06/21.
//

import UIKit

class modalViewController: UIViewController {

    @IBOutlet weak var exitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }
    
    @IBAction func buttonExitAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

//
//  MyCollectionViewCell5.swift
//  iConiki
//
//  Created by Raphael Alkamim on 29/06/21.
//

import UIKit

class MyCollectionViewCell5: UICollectionViewCell {
    
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var iconTitle: UILabel!
    
}

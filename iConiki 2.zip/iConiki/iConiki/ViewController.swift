//
//  ViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 24/06/21.
//

import UIKit
class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var col1: UICollectionView!
    @IBOutlet weak var col2: UICollectionView!
    
    
    let reuseIdentifier = "cell"
    let reuseIdentifier2 = "cell2"
    var items = ["1", "2", "3", "4"]
    var items2 = ["a", "b", "c"]
    let cards = ["Descubra unidade","Descubra brevidade","Descubra alinhamento","Descubra unidade"]
    let cards2 = ["Pratique unidade","Pratique brevidade","Pratique alinhamento"]
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == col2 {
            return self.items2.count
        }
        return self.items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == col2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier2, for: indexPath as IndexPath) as! MyCollectionViewCell2
            
            //cell.myLabel2.text = self.items2[indexPath.row]
            cell.backgroundColor = UIColor.yellow
            cell.imgCard.image = UIImage(named: cards2[indexPath.row])


            return cell
        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! MyCollectionViewCell
        
        
        //cell.myLabel.text = self.items[indexPath.row]
        cell.backgroundColor = UIColor.cyan
        cell.imgCard.image = UIImage(named: cards[indexPath.row])
        
        return cell
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if let destination = segue.destination as?
            DiscoverViewController, let index =
                col1.indexPathsForSelectedItems?.first{
            destination.card = index.row
        }
        
        if let destination = segue.destination as?
            PracticeViewController, let index =
                col2.indexPathsForSelectedItems?.first{
            destination.card = index.row
        }
        
    }
    
    
    
    
}

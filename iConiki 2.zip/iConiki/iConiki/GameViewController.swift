//
//  GameViewController.swift
//  iConiki
//
//  Created by Raphael Alkamim on 25/06/21.
//

import UIKit

class GameViewController: UIViewController {
    
    @IBOutlet weak var label1: UILabel?
    
    var card = 0
    
    let unidadeQuestions = ["Unidade1","Unidade2","Unidade3","Unidade4","Unidade5","Unidade6","Unidade7","Unidade8","Unidade9","Unidade10"]
    let brevidadeQuestions = ["Brevidade1","Brevidade2","Brevidade3","Brevidade4","Brevidade5","Brevidade6","Brevidade7","Brevidade8","Brevidade9","Brevidade10"]
    let alinhametoQuestions = ["Alinhamento1","Alinhamento2","Alinhamento3","Alinhamento4","Alinhamento5","Alinhamento6","Alinhamento7","Alinhamento8","Alinhamento9","Alinhamento10"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        label1?.text = "\(card)"


    }
    

 

}
